package ejemplosrepetitivos;


public class For {

    public static void main(String[] args) {
        
        // Nos interesa imprimir toda la tabla del nueve
        
        for (int i = 1; i < 11; i++) {
            
            System.out.println("La tabla del nueve es " + i * 9);
            
        }
        
    }

}
